declare module "*.vue" {
    import Vue from "vue";
    export default Vue;
}
/*declare module "chart.js" {
    import Chart from "chart.js";
    export default Chart;

}*/